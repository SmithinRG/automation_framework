public abstract class LoginCoreLogic {


	public abstract void verifyLoginScenario(String userName, String password)
			throws InterruptedException;
}