public class LoginTest extends CreateSession {

	LoginCoreLogic loginCoreLogic;
	String userName;
	String password;


	@Parameters({"os"})
	@BeforeMethod
	public void instantiateHelpers(String invokeDriver){
		
		//userName = localeConfigProp.getProperty("userName");
		//password = localeConfigProp.getProperty("password");

		userName = usernameP;
		password = passwordP;

		
		if (invokeDriver.equalsIgnoreCase("android")){
			loginCoreLogic = new AndroidLoginCoreLogic(driver);
		}																		         
		else if (invokeDriver.equalsIgnoreCase("iOS")){
			loginCoreLogic = new IOSLoginCoreLogic(driver);
		}
	}

	/** 
	 * method to verify login to android and iOS app
	 * @throws InterruptedException Thrown when a thread is waiting, sleeping, 
	 * or otherwise occupied, and the thread is interrupted, either before
	 *  or during the activity.
	 */ 
	@Test
	public void LoginVerification() throws InterruptedException {
		Log.info("Running login test");
		loginCoreLogic.verifyLoginScenario(userName, password);
		Log.info("Verified the login");
	}


}